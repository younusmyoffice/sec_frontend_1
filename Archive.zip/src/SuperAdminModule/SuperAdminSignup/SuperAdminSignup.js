import React from "react";
import "./SuperAdminSignup.scss";

const SuperAdminSignup = () => {
    return (
        <>
            <h1>SuperAdminSignup</h1>
        </>
    );
};

export default SuperAdminSignup;
