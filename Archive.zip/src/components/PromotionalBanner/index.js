export { default } from './PromotionalBanner';
