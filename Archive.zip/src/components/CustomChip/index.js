export { default } from "./custom-chip";
