export { default } from './NavigationTabs';
