export { default } from "./custom-tab";
