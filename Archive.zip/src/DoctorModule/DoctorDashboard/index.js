export { default } from "./doctordashboard";
