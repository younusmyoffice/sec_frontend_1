export { default } from "./PatientModule";
