export { default } from "./patientpaymentinformation";
