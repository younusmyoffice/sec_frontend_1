import React from "react";

const SuperAdminLogin = () => {
    return (
        <>
            <h1>Super Admin Login</h1>
        </>
    );
};

export default SuperAdminLogin;
