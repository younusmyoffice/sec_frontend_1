import React from "react";

function PatientModule() {
    return <div>Hello Patient !!!</div>;
}

export default PatientModule;
