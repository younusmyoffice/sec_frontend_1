export { default } from "./Chats";
