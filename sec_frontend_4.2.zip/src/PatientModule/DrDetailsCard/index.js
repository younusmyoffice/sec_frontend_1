export { default } from "./DrDetailsCard";
