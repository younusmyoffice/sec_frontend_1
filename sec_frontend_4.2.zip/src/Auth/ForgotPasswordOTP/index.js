export { default } from "./ForgotPasswordOTP";
