export { default } from "./ForgotPassword";
