export { default } from "./doctorlogin";
