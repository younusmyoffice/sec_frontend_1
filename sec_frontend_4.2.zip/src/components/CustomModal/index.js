export { default } from "./custom-modal";
