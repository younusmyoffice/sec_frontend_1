export { default } from "./ForgotPasswordChange";
