export { default } from "./patientlogin";
