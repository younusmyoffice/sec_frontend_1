export { default } from './HorizontalScrollCards';
