export { default } from './DoctorCard';
