export { default } from "./MyActivity";
