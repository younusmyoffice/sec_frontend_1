export { default } from "./Received";
