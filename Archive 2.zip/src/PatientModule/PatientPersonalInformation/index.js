export { default } from "./patientpersonalinformation";
