export { default } from "./DoctorStatistics";
