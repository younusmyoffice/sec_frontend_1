export { default } from "./DoctorManage";
