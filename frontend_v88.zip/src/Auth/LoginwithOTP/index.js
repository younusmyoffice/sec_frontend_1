export { default } from "./LoginWithOTP";
