export { default } from './LoadingSkeleton';
