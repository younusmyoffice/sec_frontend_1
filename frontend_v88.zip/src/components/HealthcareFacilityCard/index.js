export { default } from './HealthcareFacilityCard';
