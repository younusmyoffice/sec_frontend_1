export { default } from "./page-loader";
