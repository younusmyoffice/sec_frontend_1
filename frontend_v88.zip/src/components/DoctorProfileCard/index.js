export { default } from './DoctorProfileCard';
